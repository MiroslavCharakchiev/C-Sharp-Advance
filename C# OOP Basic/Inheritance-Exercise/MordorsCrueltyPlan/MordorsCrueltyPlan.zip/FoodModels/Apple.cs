﻿namespace MordorsCrueltyPlan.FoodModels
{
   public class Apple : Food
    {
        public Apple() : base(1)
        {

        }
    }
}
