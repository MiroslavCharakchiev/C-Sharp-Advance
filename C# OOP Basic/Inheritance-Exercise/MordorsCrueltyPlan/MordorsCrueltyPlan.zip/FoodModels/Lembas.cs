﻿namespace MordorsCrueltyPlan.FoodModels
{
   public class Lembas : Food
    {
        public Lembas() : base(3)
        {
        }
    }
}
