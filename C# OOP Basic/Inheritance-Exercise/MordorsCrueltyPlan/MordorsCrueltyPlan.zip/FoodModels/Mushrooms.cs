﻿namespace MordorsCrueltyPlan.FoodModels
{
   public class Mushrooms : Food
    {
        public Mushrooms() : base(-10)
        {
        }
    }
}
