﻿namespace MordorsCrueltyPlan.FoodModels
{
   public class Other : Food
    {
        public Other() : base(-1)
        {
        }
    }
}
