﻿namespace MordorsCrueltyPlan.FoodModels
{
    public class Cram : Food
    {
        public Cram() : base(2)
        {
        }
    }
}
