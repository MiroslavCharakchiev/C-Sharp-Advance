﻿namespace MordorsCrueltyPlan.MoodModels
{
   public class Happy : Mood
    {
    }
}
