﻿namespace MordorsCrueltyPlan.MoodModels
{
    public class Mood
    {
    }
}
