﻿namespace MordorsCrueltyPlan.MoodModels
{
    public class Angry : Mood
    {

    }
}
