﻿namespace MordorsCrueltyPlan.MoodModels
{
    public class Sad : Mood
    {
    }
}
