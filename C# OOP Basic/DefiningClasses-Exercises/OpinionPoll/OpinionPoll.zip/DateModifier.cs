﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace OpinionPoll
{
   public class DateModifier
   {
       private DateTime firsdate;
       private DateTime seconddate;

       public DateModifier(string first, string second)
       {
           
           this.firsdate = DateTime.ParseExact(first, "yyyy MM dd", CultureInfo.InvariantCulture);
           this.seconddate = DateTime.ParseExact(second, "yyyy MM dd", CultureInfo.InvariantCulture);
       }

       public double DateDiference()
       {
           var diference = this.firsdate - this.seconddate;
           return Math.Abs(diference.TotalDays);
       }
   }
}
