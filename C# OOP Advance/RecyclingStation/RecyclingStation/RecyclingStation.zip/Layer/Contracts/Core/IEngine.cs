﻿namespace RecyclingStation.Layer.Contracts.Core
{
    public interface IEngine
    {
        void Run();
    }
}
