﻿namespace RecyclingStation.Layer.Contracts.IO
{
    public interface IReader
    {
       string  ReadLine();
    }
}