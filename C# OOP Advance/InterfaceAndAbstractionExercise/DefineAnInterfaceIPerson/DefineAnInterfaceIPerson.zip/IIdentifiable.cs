﻿namespace DefineAnInterfaceIPerson
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
