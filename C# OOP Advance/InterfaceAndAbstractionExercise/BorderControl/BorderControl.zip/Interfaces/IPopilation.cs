﻿namespace BorderControl
{
    public interface IPopilation
    {
        string Id { get; }
    }
}
