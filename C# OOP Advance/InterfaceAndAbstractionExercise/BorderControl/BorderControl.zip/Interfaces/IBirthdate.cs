﻿namespace BorderControl.Interfaces
{
    public interface IBirthdate
    {
        string Birthdate { get; }
        string Name { get; }
    }
}
